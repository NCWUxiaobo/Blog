package com.zgw.blog.dto;

import lombok.Data;

@Data
public class UploadFileVO {

    private String src;

    private String title;

}